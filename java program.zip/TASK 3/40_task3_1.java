final class student
{
	int roll_no=40;
	String name="priyank";
	double percentage=99.99d;
	void display()
	{
		System.out.println(this.roll_no);
		System.out.println(this.name);
		System.out.println(this.percentage);
		
	}
}