abstract class Student
{
	int roll_no=40;
	String name="priyank";
	double percentage=99.99d;
	abstract void display();
}
class Student1 extends Student
{
	void display()
	{
		System.out.println(" ");
	}
}