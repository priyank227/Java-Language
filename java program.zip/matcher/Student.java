import java.util.regex.*;
class Student
{
	public static void main(String s[])
	{
		Pattern p = Pattern.compile("[A-Z]{5}[1-9]{4}[A-Z]{1}");
		Matcher m1 = p.matcher("ABCDE1234F");
		Matcher m2 = p.matcher("Gt1455GHT1");
		boolean b1 = m1.matches();
		boolean b2 = m2.matches();
		System.out.println(b1);
		System.out.println(b2);
	}
}