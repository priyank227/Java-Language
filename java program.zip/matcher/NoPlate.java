import java.util.regex.*;
class Student
{
	public static void main(String s[])
	{
		Pattern p = Pattern.compile("[GJ][1-9]{1,2}[A-Z]{1,2}[1-9][0-9]{0,3}");
		Matcher m1 = p.matcher("GJ03EG3969");
		Matcher m2 = p.matcher("GJ03PQ4277");
		Matcher m3 = p.matcher("GJ03RS87");
		System.out.println(m1.matches());
		System.out.println(m2.matches());
		System.out.println(m3.matches());
	}
}