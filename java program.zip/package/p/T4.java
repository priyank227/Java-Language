package program;
public class T4
{
	public void lab()
	{
		System.out.println("HELLO JAVA");
	}
}