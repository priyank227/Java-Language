import program.*;
class T5
{
	public static void main(String s[])
	{
		T4 t=new T4();
		t.lab();
	}
}