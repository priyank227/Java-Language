import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.lang.*;

public class Snake extends JFrame
{
	JButton[] B = new JButton[60];
	TextBox t1,t2;
	Snake()
	{
		super("Snake Game");
		setBounds(0,0,1500,1000);
		setLayout(new GridLayout(5,12));
		setSize(1000,1000);
		
		t1 = new TextField("Red");
		t2 = new TextFileld("Green");
		
		add(t1);
		add(t2);
		
		Font f1 = new Font("Arial",Font.BOLD,40);
		t1.setFont(f1);
		t2.setFont(f1);
		
		for(int i=0;i<B.length;i++)
		{
			B[i] = new JButton(new String().valueOf(i+1));
		}
		
		for(int i=0;i<B.length;i++)
		{
			add(B[i]);
		}
		
		addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent we)
				{
					System.exit(0);
				}
			});
	}
	public static void main(String args[])
	{
		Snake s = new Snake();
		s.setVisible(true);
	}
}