// in abstract class may be method will final.
abstract class School
{
	final void conductExam()
	{
		System.out.println("123");
	}
}
class College extends School
{
	public static void main(String s[])
	{
		College t=new College();
		t.conductExam();
	}
}