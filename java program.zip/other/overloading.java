//method overloading
class T1
{
	public static int mul(int a,int b)
	{
		return a*b;
	}
	public static int mul(int a,int b,int c)
	{
		return a*b*c;
	}
	public static void main(String s[])
	{
		System.out.println(mul(5,6));
		System.out.println(mul(5,6,7));
	}
}

//cunstructor overloading
class Addition
{
	int i,j;
	Addition()
	{
		i=15;
		j=10;
	}
	Addition(int x,int y)
	{
		i=x;
		j=y;
	}
	int sum()
	{
		return i+j;
	}
	public static void main(String s[])
	{
		Addition a1 = new Addition();
		Addition a2 = new Addition(8,9);
		System.out.println(a1.sum());
		System.out.println(a2.sum());
	}
}