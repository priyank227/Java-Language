class Ractangle
{
	int l;
	int b;
	Ractangle()
	{
		l=3;
		b=4;
	}
	Ractangle(int x,int y)
	{
		l=x;
		b=y;
	}
	int area_of_ractangle()
	{
		return l*b	;
	}
	public static void main(String s[])
	{
		Ractangle r1 = new Ractangle();
		Ractangle r2 = new Ractangle(10,20);
		System.out.println(r1.area_of_ractangle());
		System.out.println(r2.area_of_ractangle());
	}
}