import java.util.*;
class Palindrom
{
	public static void main(String s[])
	{
		String a,b="";
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string:");
		a=sc.nextLine();
		int n=a.length();
		 
		for(int i=n-1;i>=0;i--)
		{
			b=b+a.charAt(i);
		}
		if(a.equalsIgnoreCase(b))
		{
			System.out.println("the string is pelindrom");
		}
		else
		{
			System.out.println("the string is not palindrom");
		}
	}	
	
}