class Time
{
	int hr,min;
	Time()
	{
		hr=10;
		min=10;
	}
	Time(int j, int k)
	{
		hr=j;
		min=k;
	}
	int TimeInMinute()
	{
		return ((hr*60)+min);
	}
	void findBigTime(Time x)
	{
		if(x.TimeInMinute() > this.TimeInMinute())
		{
			System.out.println("Time Passed As An Arg Is Bigger");
		}
		else
		{
			System.out.println("Calling Time Is Bigger");
		}
	}
	public static void main(String p[])
	{
		Time t1 = new Time();
		System.out.println(t1.TimeInMinute());
		Time t2 = new Time(5,45);
		System.out.println(t2.TimeInMinute());
		t1.findBigTime(t2);
	}
}