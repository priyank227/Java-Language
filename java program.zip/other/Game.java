import java.util.Random;
class Game extends Thread
{
	public void run()
	{
		Random r = new Random();
		for(int i=0;i<=60;i++)
		{
			int n = r.nextInt(6);
			System.out.println("Number :"+n);
			
			try
			{
				Thread.sleep(1000);
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
	}
}
class Main
{
	public static void main(String s[])
	{
		Game g = new Game();
		g.start();
	}
}