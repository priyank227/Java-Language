class Priyank
{
	public static void name()
	{
		System.out.println("priyank");
	}
	public void callege()
	{
		System.out.println("marwadi");
	}
	public static void main(String s[])
	{
		Priyank p = new Priyank();
		p.name();
		p.callege();
	}
}