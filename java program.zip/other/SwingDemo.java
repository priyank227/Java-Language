import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.IOException;
import javax.swing.JPanel;
public class SwingDemo extends javax.swing.JFrame {
   Image img = Toolkit.getDefaultToolkit().getImage("D:\\SEM 2\\OOPS JAVA\\123.png");
   public SwingDemo() throws IOException {
      this.setContentPane(new JPanel() {

         public void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(img,0,0,null);
         }
      });
      pack();
      setVisible(true);
	  setSize(1000,1000);
   }
   public static void main(String[] args) throws Exception {
      new SwingDemo();
   }
}