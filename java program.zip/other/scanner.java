import java.util.*
class Employee
{
	public static void main(String s[])
	{
		int id;
		Scanner c=new Scanner(System.in)
		System.out.println("enter the employee id:");
		id=sc.nextInt();
		sc.nextLine();
		
		String name;
		System.out.println("enter the employee name:");
		name=sc.nextLine();
		
		int sallary;
		System.out.println("enter the salary:");
		salary = sc.nextLine();
		
		String state;
		System.out.println("enter the state:");
		state=sc.nextLine();
		
		System.out.println("employee id:"+id);
		System.out.println("employee id:"+name);
		System.out.println("employee id:"+salary);
		System.out.println("employee id:"+state);
	}
}