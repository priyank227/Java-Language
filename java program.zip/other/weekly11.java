import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.lang.*;

public class Weekly11 extends Frame
{
	Checkbox ch1,ch2,ch3,ch4,ch5,ch6,ch7;
	Button b1;
	TextField t1;
	Label l1,l2;
	CheckboxGroup cg;
	MyActionListner m1 = new MyActionListner(this);
	
	Weekly11()
	{
		super("Check Eligiblity");
		setLayout(null);
		setBackground(color.RED);
		setBounds(0,0,1000,1000);
		setVisible(true);
		
		Font f1 = new Font("Arial",Font.BOLD,20);
		
		ch1 = new checkbox("MALE",cg,false);
		ch2 = new checkbox("MALE",cg,false);
		ch3 = new checkbox("MALE",cg,false);
		ch4 = new checkbox("MALE",cg,false);
		ch5 = new checkbox("MALE",cg,false);
		ch6 = new checkbox("MALE",cg,false);
		ch7 = new checkbox("MALE",cg,false);
		t1 = new TextField();
		l1 = new Lable("select gender");
		l2 = new Lable("select hobby");
		b1 = new Button("check eligiblity");
		
		
		
	}
}