import java.util.*;
class Pelindrom
{
	public static void main(String s[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("enter the string:");
		String st=sc.nextLine();
		int k=1;
		for(int i=0;i<st.length()/2;i++)
		{
			if(st.charAt(i)!=st.charAt(st.length()-1-i))
			{
				k=0;
				break;
			}
		}
		if(k==1)
		{
			System.out.println("string is pelindrom");
		}
		else
		{
			System.out.println("string is not pelidrom");
		}
		
	}	
}