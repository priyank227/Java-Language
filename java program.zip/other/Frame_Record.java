import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.lang.*;

public class Frame_Record extends Frame
{
	TextField t1,t2,t3;
	Button b1,b2,b3,b4,b5,b6,b7,b8;
	Label l1,l2,l3;	
	//Calc_ActionListener m1 = new Calc_ActionListener(this);
	Frame_Record()
	{
		super("Records");
		setLayout(null);
		setBounds(0,0,650,850);
		
		t1=new TextField();
		t2=new TextField();
		t3=new TextField();
		
		b1=new Button("SAVE");
		b2=new Button("CLEAR");
		b3=new Button("NEXT");
		b4=new Button("PREVIOUS");
		b5=new Button("FIRST");
		b6=new Button("LAST");
		b7=new Button("UPDATE");
		b8=new Button("DELETE");
		
		l1 = new Label("number:");
		l2 = new Label("name :");
		l3 = new Label("city:");
		
		add(t1);
		add(t2);
		add(t3);
		
		add(b1);
		add(b2);
		add(b3);
		add(b4);
		add(b5);
		add(b6);
		add(b7);
		add(b8);
		
		add(l1);
		add(l2);
		add(l3);
		
		t1.setBounds(300,50,300,100);
		t2.setBounds(300,200,300,100);
		t3.setBounds(300,350,300,100);
		b1.setBounds(50,500,100,100);
		b2.setBounds(200,500,100,100);
		b3.setBounds(350,500,100,100);
		b4.setBounds(500,500,100,100);
		b5.setBounds(50,650,100,100);
		b6.setBounds(200,650,100,100);
		b7.setBounds(350,650,100,100);
		b8.setBounds(500,650,100,100);
		l1.setBounds(50,50,200,100);
		l2.setBounds(50,200,200,100);
		l3.setBounds(50,350,200,100);
		
		Font f1 = new Font("Arial",Font.BOLD,50);
		Font f2 = new Font("Arial",Font.BOLD,20);
		b1.setFont(f2);
		b2.setFont(f2);
		b3.setFont(f2);
		b4.setFont(f2);
		b5.setFont(f2);
		b6.setFont(f2);
		b7.setFont(f2);
		b8.setFont(f2);
		l1.setFont(f1);
		l2.setFont(f1);
		l3.setFont(f1);
		
		/*b1.addCalc_ActionListener(ml);
		
		addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent we)
				{
					System.exit(0);
				}
			});*/
	}
	public static void main(String args[])
	{
			Frame_Record cf = new Frame_Record();
			cf.setVisible(true);
	}
}