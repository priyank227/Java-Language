import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.lang.*;

public class Listener implements ActionListener
{
	Snake s;
	Listener(Snake se)
	{
		this.s = se;
	}
	
}