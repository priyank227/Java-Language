// using comparator it means in one class two types of sorting or more than one parameter comparein comparator
import java.util.*;
class Sort implements Comparator<Student>
{
	public int compare(Student s1,Student s2)
	{
		return s1.name.compareTo(s2.name);
	}
}
class Student implements Comparable<Student>
{
	String name;
	int roll_no;
	double mark;
	
	Student(String a,int b,double c)
	{
		this.name=a;
		this.roll_no=b;
		this.mark=c;
	}
	public String toString()
	{
		return this.name+" # "+this.roll_no+" # "+this.mark;
	}
	public int compareTo(Student s)
	{
		return new Double(-this.mark+s.mark).intValue();
	}
	public static void main(String s[])
	{
		Student st[]=new Student[4];
		st[0]=new Student("malhar",27,80.36);
		st[1]=new Student("deep",49,88.36);
		st[2]=new Student("priyank",40,99.36);
		st[3]=new Student("jeel",74,90.36);
		
		System.out.println("print as it is as input:");
		for(int i=0;i<st.length;i++)
		{
			System.out.println(st[i]);
		}
		System.out.println(" ");
		System.out.println("sorting on marks:");
		Arrays.sort(st);
		for(int i=0;i<st.length;i++)
		{
			System.out.println(st[i]);
		}
		System.out.println(" ");	
		System.out.println("sorting on name:");
		Arrays.sort(st,new Sort());
		for(int i=0;i<st.length;i++)
		{
			System.out.println(st[i]);
		}
	}
}