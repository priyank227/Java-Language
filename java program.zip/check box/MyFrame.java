import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.lang.*;

public class MyFrame extends Frame
{
	Checkbox c1,c2,c3,c4,c5,c6;
	Button b1;
	MyActionListener ml = new MyActionListener(this);
	MyFrame()
	{
		super("selecting hobby");
		setLayout(null);
		setBounds(0,0,1200,1200);
		
		c1 = new Checkbox("reading");
		c2 = new Checkbox("traveling");
		c3 = new Checkbox("playing");
		c4 = new Checkbox("horse riding");
		c5 = new Checkbox("gaming");
		c6 = new Checkbox("cooking");
		b1 = new Button("submit");
		
		add(c1);
		add(c2);
		add(c3);
		add(c4);
		add(c5);
		add(c6);
		add(b1);
		
		c1.setBounds(100,100,500,200);
		c2.setBounds(100,200,500,200);
		c3.setBounds(100,300,500,200);
		c4.setBounds(100,400,500,200);
		c5.setBounds(100,550,500,200);
		c6.setBounds(100,600,500,200);
		b1.setBounds(100,700,500,200);
		
		Font f1 = new Font("Arial",Font.BOLD,20);
		c1.setFont(f1);
		c2.setFont(f1);
		c3.setFont(f1);
		c4.setFont(f1);
		c5.setFont(f1);
		c6.setFont(f1);
		
		c1.addItemListener(ml);
		c2.addItemListener(ml);
		c3.addItemListener(ml);
		c4.addItemListener(ml);
		c5.addItemListener(ml);
		c6.addItemListener(ml);
		
		addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent we)
				{
					System.exit(0);
				}
			});
	}
	public static void main(String args[])
	{
			MyFrame mf = new MyFrame();
			mf.setVisible(true);
	}
}