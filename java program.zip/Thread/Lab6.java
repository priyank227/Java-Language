//take any one number using random method and print its square and cube using 3 thread.
import java.util.Random;
class Square extends Thread
{
	int i;
	Square(int n)
	{
		i=n;
	}
	public void run()
	{
		int Square = i*i;
		System.out.println("Square of i="+Square);
	}
}

class Cube extends Thread
{
	int i;
	Cube(int n)
	{
		i=n;
	}
	public void run()
	{
		int Cube = i*i*i;
		System.out.println("Cube="+Cube);
	}
}

class Number extends Thread
{
	public void run()
	{
		Random random = new Random();
		for(int i=0;i<=10;i++)
		{
			int n = random.nextInt(10);
			System.out.println("number:"+n);
			
			Square s = new Square(n);
			s.start();
			Cube c = new Cube(n);
			c.start();
                                               // two ways of calling
			//new Square().start(n);      
			//new Cube().start(n);

			try
			{
				Thread.sleep(1000);      //take 1 sec break
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
	}
}
class Book
{
	public static void main(String s[])
	{
		//Number n = new Number();       // two ways of calling
		//n.start();
		new Number().start();
	}
}