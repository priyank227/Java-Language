class MyTest extends Thread
{
	int no;
	MyTest(int i)
	{
		this.no=i;
	}
	public void run()
	{
		for(int i=0;i<this.no;i++)
		{
			System.out.println(i);
			try
			{
				Thread.sleep(1);
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
	}
}
class Test
{
	public static void main(String args[])
	{
		MyTest mt1 = new MyTest(10);
		mt1.start();
	}
}