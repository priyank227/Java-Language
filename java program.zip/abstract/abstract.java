// when class is public , file name should be public class name.
abstract class School
{
	abstract public void conductExam();
}
class College extends School
{
	public void conductExam()
	{
		System.out.println("present compulsory");
	}
	public static void main(String s[])
	{
		College t=new College();
		t.conductExam();
	}
}