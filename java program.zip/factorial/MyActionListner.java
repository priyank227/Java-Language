import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.lang.*;
import java.util.*;
class MyActionListener implements ActionListener
{
	Factorial mf;
	MyActionListener(Factorial m)
	{
		this.mf = m;
	}
	public void actionPerformed(ActionEvent e)
	{
		int s = Integer.parseInt(this.mf.t1.getText());
		int total = 1;
		
		while(s>0)
		{
			total = total*s;
			s--;
		}
		String str = String.valueOf(total);
		if(e.getSource().equals(this.mf.b1))
		{
			this.mf.t2.setText(str);
		}
	}
}