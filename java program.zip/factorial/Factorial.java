import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.lang.*;
class Factorial extends Frame
{
	TextField t1,t2;
	JButton b1;
	Label l1;
	MyActionListener ml = new MyActionListener(this);
	Factorial()
	{
		
		super("Factorial");
		setLayout(null);
		setBounds(0,0,700,700);
		
		t1=new TextField();
		t2=new TextField();
		l1=new Label("Enter the number:");
		
		b1 = new JButton("Factorial");
		
		add(t1);
		add(t2);
		add(l1);
		add(b1);
		
		l1.setBounds(50,50,200,100);
		t1.setBounds(300,50,200,100);
		t2.setBounds(150,200,300,100);
		b1.setBounds(200,350,200,100);
		
		Font f1 = new Font("Arial",Font.BOLD,20);
		l1.setFont(f1);
		t1.setFont(f1);
		t2.setFont(f1);
		b1.setFont(f1);
		
		t1.addActionListener(ml);
		t2.addActionListener(ml);
		b1.addActionListener(ml);
		
		addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent we)
				{
					System.exit(0);
				}
			});
		
	}
	
	public static void main(String s[])
	{
		Factorial mf = new Factorial();
			mf.setVisible(true);
	}
}